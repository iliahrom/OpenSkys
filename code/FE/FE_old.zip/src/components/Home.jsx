import React from "react";
import { Link } from "react-router-dom";
import styles from "../styles/Home.module.css";

const drones = [
  { id: 1, name: "DJI Tello" },
  { id: 2, name: "Delivery Drone" },
  { id: 3, name: "Surveillance Drone" },
];

function Home() {
  return (
    <div className={styles.container}>
      <h2>Drone Types</h2>
      <ul className={styles.list}>
        {drones.map((drone) => (
          <li key={drone.id} className={styles.item}>
            <h3>{drone.name}</h3>
            <Link to={`/details/${drone.id}`} className={styles.detailsButton}>
              View Details
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Home;




