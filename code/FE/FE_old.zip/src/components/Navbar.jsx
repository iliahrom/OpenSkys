import React from "react";
import { Link } from "react-router-dom";
import styles from "../styles/Navbar.module.css"; // ✅ Import CSS module

const Navbar = ({ user, handleLogout }) => {
  return (
    <nav className={styles.navbar}>
      <ul className={styles.navLinks}>
        <li>
          <Link to="/" className={styles.navLink}>
            Home
          </Link>
        </li>
        <li>
          <Link to="/about" className={styles.navLink}>
            About Us
          </Link>
        </li>
        <li>
          <Link to="/contact" className={styles.navLink}>
            Contact
          </Link>
        </li>
        <li>
          <Link to="/flight-points" className={styles.navLink}>
            Flight Points
          </Link>
        </li>
        {user && (
          <li>
            <button onClick={handleLogout} className={styles.logoutButton}>
              Logout
            </button>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;
