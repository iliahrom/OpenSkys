import React from "react";
import { useParams, Link } from "react-router-dom";
import styles from "../styles/Details.module.css";

const droneDetails = {
  1: {
    name: "DJI Tello",
    description: "A compact and powerful drone for beginners and professionals alike.",
    image: "/assets/drone1.jpg",
  },
  2: {
    name: "Delivery Drone",
    description: "Designed for efficient and fast package deliveries in urban areas.",
    image: "/assets/drone2.jpg",
  },
  3: {
    name: "Surveillance Drone",
    description: "Used for security and monitoring, offering high-quality live footage.",
    image: "/assets/drone3.jpg",
  },
};

function Details() {
  const { id } = useParams();
  const drone = droneDetails[id];

  if (!drone) {
    return <h2>Drone not found</h2>;
  }

  return (
    <div className={styles.container}>
      <h2>{drone.name}</h2>
      <img src={drone.image} alt={drone.name} className={styles.droneImage} />
      <p>{drone.description}</p>
      <Link to="/" className={styles.backButton}>
        Back to Home
      </Link>
    </div>
  );
}

export default Details;



