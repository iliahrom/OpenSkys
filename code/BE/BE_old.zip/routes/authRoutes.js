const express = require("express");
const { registerUser, loginUser, logoutUser } = require("../controllers/authController");

const router = express.Router();

// רישום משתמש
router.post("/register", registerUser);

// התחברות משתמש
router.post("/login", loginUser);

// יציאת משתמש (Logout)
router.post("/logout", logoutUser);

module.exports = router;




