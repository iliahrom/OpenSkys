const express = require("express");
const { getDrones } = require("../controllers/droneController");

const router = express.Router();

// נתיב לקבלת כל הרחפנים
router.get("/", getDrones);

module.exports = router;
