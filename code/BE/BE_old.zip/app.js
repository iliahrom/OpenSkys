const express = require("express");
const session = require("express-session"); // ניהול סשן בזיכרון השרת
const cors = require("cors");
const dbSingleton = require("./dbSingleton");
const authRoutes = require("./routes/authRoutes");
const contactRoutes = require("./routes/contactRoutes");

const app = express();
const port = 5000;

// הגדרת JSON Middleware
app.use(express.json());

// הגדרת CORS כדי לאפשר הפעלת Cookies ל-Session
app.use(
  cors({
    origin: ["http://localhost:3000", "http://127.0.0.1:3000"],
    credentials: true,
  })
);

// ניהול Session (מאוחסן בזיכרון השרת)
app.use(
  session({
    secret: "mySecretKey", 
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, httpOnly: true, maxAge: 1000 * 60 * 60 }, 
  })
);

// התחברות למסד נתונים (בודק חיבור)
const db = dbSingleton.getConnection();
db.query("SELECT 1", (err) => {
  if (err) {
    console.error("❌ Database connection failed:", err);
  } else {
    console.log("✅ Connected to MySQL database!");
  }
});

// הגדרת הנתיבים
app.use("/api/auth", authRoutes);

// בדיקה שהשרת רץ
app.get("/", (req, res) => {
  res.send("✅ Server is running!");
});

app.use("/api/contact", contactRoutes);

// הפעלת השרת
app.listen(port, "0.0.0.0", () => {
  console.log(`🚀 Server running on port ${port}`);
});





