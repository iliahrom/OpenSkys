const dbSingleton = require("../dbSingleton");

const getDrones = (req, res) => {
  const sql = "SELECT * FROM drones";
  const db = dbSingleton.getConnection();

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
};

module.exports = { getDrones };
